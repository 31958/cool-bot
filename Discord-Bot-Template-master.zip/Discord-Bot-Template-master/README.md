
# Just a simple discord bot template

<a href="https://nodejs.org/en/">Node.js</a> needs to be installed for this to work and be tested. 

This bot also comes with a freely done 'ping' command.

I recommend this series for starters: <a href="https://www.youtube.com/channel/UC08G-UJT58SbkdmcOYyOQVw/videos">link</a>
