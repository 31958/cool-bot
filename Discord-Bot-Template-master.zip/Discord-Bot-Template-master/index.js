const Discord = require('discord.js');
const bot = new Discord.Client();

const token = ''; //Add you token in here

const PREFIX = ''; //Add your prefix here

//This function will send a message in you terminal log to show that your bot is online.
bot.on('ready', () =>{
    console.log(`This bot is online! Woohoo ${bot.user.tag}!!`);
})

//A simple function set up to add command to. Use case and break to open and close a new command under the starting 'ping' command
bot.on('message', message=>{

    let args = message.content.substring(PREFIX.length).split(" ");

    switch(args[0]){
        case 'ping':
            message.channel.send('Pong!');
        break;
    }
})

bot.login(token);
